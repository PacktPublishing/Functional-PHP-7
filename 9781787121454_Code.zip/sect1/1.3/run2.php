<?php
/**
 * Volume 1 - PHP Crash Course - Video 1.3
 * Author: @luijar
 * Run 2
 */
declare(strict_types=1);

namespace Vol1\Sect1\Video3;

require_once 'toAll.php';

toAll(__NAMESPACE__. '\consoleLog', ['Functional', 'PHP', 'Rocks!']);