<?php
/**
 * Volume 1 - Section 1 - Video 1.2
 * Author: @luijar
 * Sample code to showcase Closures
 */
namespace Vol1\Sect1\Video2;

var_dump(function () {});